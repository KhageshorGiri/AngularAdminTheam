import {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
} from "./chunk-DWID6KRJ.js";
import "./chunk-4QRCQLYD.js";
import "./chunk-WE4GMWBV.js";
export {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
};
//# sourceMappingURL=@angular_cdk_layout.js.map
